cp rtklaunch_qt ../../../RTKLIB_bin/bin
