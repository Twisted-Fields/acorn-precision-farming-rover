cp srctblbrows_qt ../../../RTKLIB_bin/bin
