function testpeph2

C=299792458.0;
dirs='../data/sp3';
td=caltomjd([2010,4,1]);
time=0:30:86400*2-30;

ephs=textread('testpeph2.out');
ephs(ephs==0)=nan;

sat=sprintf('GPS%02d',ephs(1,1));

ephr=readeph(td,time,{sat},dirs,'igs',24,'interp');
clkr=readclk(td,time,{sat},dirs,'igs',24,'interp');

for i=1:length(time)
    clkr(i,1)=clkr(i,1)-2*ephr(i,1:3)*ephr(i,4:6)'/C^2;
end
dpos=ephs(:,3:6)-ephs(:,7:10);

figure('color','w'), hold on, box on, grid on
plot(time/3600,dpos)
xlabel('time (hr)');
ylabel('error (m)');
xlim(time([1,end])/3600);
ylim([-10,10]);
legend({'x','y','z','clk'})
text(0.02,0.95,sprintf('STD: X=%.4f Y=%.4f Z=%.4f CLK=%.4fm',...
     std(dpos(~isnan(dpos(:,1)),1:3)),std(dpos(~isnan(dpos(:,4)),4))),...
     'units','normalized')
title(sprintf('testpeph: brdc-prec ephemeris %s',sat));
moveax
